	function calculate(){
var a = document.getElementById("t1").value;
        var b = document.getElementById("t2").value;
        var c = document.getElementById("t3").value;
		var d = document.getElementById("t4").value;
		
		var f=parseFloat(a)+parseFloat(b)+parseFloat(c)+parseFloat(d);
		var g=(3);
		var h=f*g;
		//document.getElementById("hell").innerHTML = ("Total Amount :"+h);	
		t5.value=h;
		event.preventDefault();
		
}